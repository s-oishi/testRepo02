package management;

public class ShowTicketSystem {
	public ShowTicketSystem() {

	}

	public void indicateAllTicketInfo() {
	}

	public int searchTicketInfoNo() {
	}

	public String[] getAllTicketInfo() {
	}

	public String[] useShowSystem(String id) {
	}
}
