package management;

public class ReservationSystem {
	public ReservationSystem() {

	}

	public void ticketReserve() {
	}

	public void ticketCancel() {

	}

	public void checkTicket(int ticketNo) {
	}

	public void checkSheetsNumer(int sheetsNo) {
	}

	public boolean checkReservation(int reservationNo) {
	}

	public boolean cancel(int reservationNo) {
	}

	public void sendID(ID id) {
	}
}
