package management;

public class LoginSystem {
	public LoginSystem() {

	}

	public boolean userCheck(String id, String pass) {

	}
}
