package ui;

import domain.Reservation;
import domain.Ticket;

public class UI {
	public UI() {

	}

	public String userLoginID() {

	}

	public String userLoginPass() {
	}

	public String inputID() {
	}
	public void selectSystem(int system) {
		
	}
	public String inputPass() {
		
	}
	public void inputTicktNo() {
		
	}
	public void inputSheetsNumber() {
		
	}
	public int inputReservation() {
		
	}
	public boolean checkCancel() {
		
	}
	public void showNotingTicket() {
		
	}
	public void showAllTicketInfo(Ticket ticketInfo[]) {
		
	}
	public void showAllResersveInfo(Reservation ReservationInfo[]) {
		
	}
}
