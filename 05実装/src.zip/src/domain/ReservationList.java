package domain;

public class ReservationList {

}
