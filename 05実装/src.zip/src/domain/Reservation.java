package domain;

public class Reservation {

}
