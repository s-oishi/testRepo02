package domain;

public class MemberList {

}
