package domain;

public class Ticket {

}
