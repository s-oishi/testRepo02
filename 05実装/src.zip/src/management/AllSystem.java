package management;

import ui.UI;

public class AllSystem {
	private UI ui =new UI();
	public AllSystem(){
		
	}
	public void start() {
		
	}
}
