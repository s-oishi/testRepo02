package management;

public interface System {

}
