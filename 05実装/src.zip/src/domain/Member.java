package domain;

public class Member {
	String id;
	String passward;
	String memberName;

	public Member() {

	}

	public String getPass() {

	}

	public String getMemberName(String id) {

	}
}
