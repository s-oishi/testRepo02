package domain;

public class TicketList {

}
